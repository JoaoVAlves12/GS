package com.brokenbrain.agro.dto;

import com.brokenbrain.agro.entity.Agricultor;

public record DadosListagemAgricultor(

		Long id, String username, String cidade, String planta, Estacao estacao) {

	public DadosListagemAgricultor(Agricultor agricultor) {
		this(agricultor.getId(), agricultor.getUsername(), agricultor.getPlanta(), agricultor.getCidade(),
				agricultor.getEstacao());

	}

}
