package com.brokenbrain.agro.dto;

public enum Estacao {

	VERÃO, OUTONO, INVERNO, PRIMAVERA

}
