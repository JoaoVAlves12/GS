package com.brokenbrain.agro.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/gpt")
public class GptController {

	@GetMapping
	public String verao() {
		return "Algumas plantas podem ser cultivadas em todo país durante esta estação, como o nabo, a abobrinha de tronco, o pepino, o repolho, o feijão de vagem, a cenoura e a alface de verão e a couve-brócoli";
	}

	@GetMapping
	public String outono() {
		return "É hora de plantar Abóboras , Abobrinhas , Tomates , Salsas , Repolhos , Coentros , Pepinos , Melões , Melancias e Rabanetes";
	}

	@GetMapping
	public String inverno() {
		return "Margarida, cravina, beijinho e calêndula são as espécies para serem plantadas no outono. Já no inverno invista em capuchinha, dália, gérbera, amor-perfeito ou gerânio";
	}

	@GetMapping
	public String primavera() {
		return "perfeita para o plantio de Abóboras, Cenouras, Melancias, Berinjelas, Mostardas,Tomates e Pimentões";
	}

}
