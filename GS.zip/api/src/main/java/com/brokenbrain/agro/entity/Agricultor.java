package com.brokenbrain.agro.entity;

import com.brokenbrain.agro.dto.DadosCadastroAgricultor;
import com.brokenbrain.agro.dto.Estacao;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Table(name = "agricultor")
@Entity(name = "Agricultor")
public class Agricultor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String username;
	private String cidade;
	private String planta;

	@Enumerated(EnumType.STRING)
	private Estacao estacao;

	public Agricultor(DadosCadastroAgricultor dados) {
		this.id = dados.id();
		this.username = dados.username();
		this.cidade = dados.cidade();
		this.planta = dados.planta();
		this.estacao = dados.estacao();

	}

	public final Long getId() {
		return id;
	}

	public final void setId(Long id) {
		this.id = id;
	}

	public final String getUsername() {
		return username;
	}

	public final void setUsername(String username) {
		this.username = username;
	}

	public final String getCidade() {
		return cidade;
	}

	public final void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public final String getPlanta() {
		return planta;
	}

	public final void setPlanta(String planta) {
		this.planta = planta;
	}

	public final Estacao getEstacao() {
		return estacao;
	}

	public final void setEstacao(Estacao estacao) {
		this.estacao = estacao;
	}

}
