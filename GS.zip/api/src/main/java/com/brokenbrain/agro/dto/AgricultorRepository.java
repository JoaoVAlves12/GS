package com.brokenbrain.agro.dto;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.brokenbrain.agro.entity.Agricultor;

public interface AgricultorRepository extends JpaRepository<Agricultor, Long> {

	Page<Agricultor> findAllByAtivoTrue(Pageable paginacao);

}
