package com.brokenbrain.agro.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DadosCadastroAgricultor(

		@NotBlank Long id, @NotBlank String username, @NotBlank String cidade, @NotBlank String planta,
		@NotNull Estacao estacao) {

}
